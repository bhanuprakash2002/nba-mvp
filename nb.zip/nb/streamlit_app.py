from nba_mvp_predictor import web

web.run()
