from nba_mvp_predictor import cli

if __name__ == "__main__":
    exit(cli.run())
